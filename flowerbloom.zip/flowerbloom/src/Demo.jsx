import React from 'react'

const Demo = () => {
  return (
    <>
    <button>Home</button>
    <br/>
    <button>About us</button>
    <br/>
    </>
  )
}

export default Demo