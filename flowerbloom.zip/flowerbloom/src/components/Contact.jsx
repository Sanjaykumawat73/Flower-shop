import React from 'react';
import './contact.css'; // Import the CSS

const Contact = () => {
  return (
    <section className="contact-section">
      <div className="contact-overlay">
        <div className="contact-container">
          <h2><span style={{ color: '#ff6b81' }}>Contact FlowerShop</span></h2>
          <p>We’d love to hear from you! Reach out for custom bouquets, delivery info, or general inquiries.</p>
          
          <form className="contact-form">
            <input type="text" name="name" placeholder="Your Name" required />
            <input type="email" name="email" placeholder="Your Email" required />
            <input type="text" name="subject" placeholder="Subject" required />
            <input type="tel" name="phone" placeholder="Your Phone Number" required />
            <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
