import Carousel from 'better-react-carousel'
import React from 'react'
import './Gallery.css' 

const Gallery = () => {
  return (
   <>
   <div className='gallery-container'>
   <Carousel cols={3} rows={2} loop autoplay={3000} showDots showArrow={false} className='carousel__item'>
    <Carousel.Item>
      <img src="https://www.nature-and-garden.com/wp-content/uploads/sites/4/2022/04/lily.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://i.pinimg.com/736x/c2/29/dd/c229dd69f96494a076a910437ec5ebbb.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://www.bbassets.com/media/uploads/p/l/40336055_1-fresho-red-rose-bouquet.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://blacktulipflowers.in/wp-content/uploads/2024/05/3-2-1.png" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/29057886/2024/4/19/7b1289ec-5ced-4bea-a410-964f742878d81713515912718FreshFlowers2.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://api.floraindia.com/upload/fgzxvH4pRY1736589212842.webp" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://www.giftacrossindia.com/media/catalog/product/g/a/gaivalhd20170333.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://assets.oyegifts.com/flowers-n-gifts/vendordata/product/unbox178_1_1.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://www.bettergiftflowers.com/wp-content/uploads/2021/03/love-in-the-air-combo-of-rose-bouquet-ferrero-chocolates-and-teddy.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://floristchennai.com/cdn/shop/products/pink-roses-teddy-and-chocolates.jpg?v=1680934410" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://www.nature-and-garden.com/wp-content/uploads/sites/4/2022/04/lily.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
    <Carousel.Item>
      <img src="https://i.pinimg.com/736x/c2/29/dd/c229dd69f96494a076a910437ec5ebbb.jpg" height="300px" width="400px"  alt="Flower 1" />
    </Carousel.Item>
   </Carousel>
   </div>
   </>
  )
}

export default Gallery