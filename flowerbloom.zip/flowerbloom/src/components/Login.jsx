import React from 'react';
import './auth.css';

const Login = () => {
  return (
    <div className="auth-page">
      <div className="auth-box">
        <h2>Login</h2>
        <form className="auth-form">
          <input type="email" name="email" placeholder="Email" required />
          <input type="password" name="password" placeholder="Password" required />
          <button type="submit">Login</button>
        </form>
        <p className="toggle-link">
          Don't have an account? <a href="/signup">Sign Up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
