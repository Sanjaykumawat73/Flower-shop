import React from 'react';
import './auth.css';

const Signup = () => {
  return (
    <div className="auth-page">
      <div className="auth-box">
        <h2>Sign Up</h2>
        <form className="auth-form">
          <input type="text" name="name" placeholder="Full Name" required />
          <input type="email" name="email" placeholder="Email" required />
          <input type="password" name="password" placeholder="Password" required />
          <input type="password" name="confirmPassword" placeholder="Confirm Password" required />
          <button type="submit">Sign Up</button>
        </form>
        <p className="toggle-link">
          Already have an account? <a href="/login">Login</a>
        </p>
      </div>
    </div>
  );
};

export default Signup;
