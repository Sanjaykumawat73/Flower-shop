import React from 'react';
import './about.css'; // Import the CSS

const About = () => {
  return (
    <section className="about-section">
      <div className="about-overlay">
        <div className="about-content">
          <h1>Welcome to Blossom Boutique</h1>
          <p>
            At Blossom Boutique, we believe flowers speak the language of love and joy.
            From stunning bouquets to elegant arrangements, our flower shop offers the
            freshest blooms handpicked just for you. Whether it’s a celebration, a
            heartfelt gesture, or just because—our flowers bring every moment to life.
          </p>
          <p>
            Visit us to explore our wide variety of roses, lilies, orchids, and seasonal
            flowers. Each bouquet is crafted with care and passion by our expert florists.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
