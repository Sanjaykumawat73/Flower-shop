import React from 'react'
import "./Home.css"
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate=useNavigate();
  const navigateToShopHere = () => {
    navigate("/gallery");
  }
  return (
   <>
   <div className="home-container">
   <div className="home_main">
   <h1>Welcome <i>Flower <span style={{color: "hotpink"}}>Shop</span></i></h1>
   <p><i>where every plant blooms into flower and fill your life with joy</i></p>
   <button onClick={()=>navigateToShopHere()}>Shop Here</button>
   </div>
   </div>
   </>
  )
}

export default Home